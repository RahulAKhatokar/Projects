const express = require("express");
const axios = require("axios");

const app = express();

app.get("/weather", async (req, res) => {

    const city = req.query.city;

    try {
        const response = await axios.get(
            `Your_API_key_here`,
        );

        res.json({
        city: response.data.name,
        temperature: response.data.main.temp,
        feels_like: response.data.main.feels_like,
        condition: response.data.weather[0].description,
        humidity: response.data.main.humidity,
        wind_speed: response.data.wind.speed
        });

    } catch (error) {
    console.log(error.message);
    res.send("Error fetching weather");
    }
});

app.listen(3000, () => {
    console.log("Server running on port 3000");
});