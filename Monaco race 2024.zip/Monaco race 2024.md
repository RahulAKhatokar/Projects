```python
pip install folium
```

    Requirement already satisfied: folium in c:\users\rahul\anaconda3\lib\site-packages (0.16.0)Note: you may need to restart the kernel to use updated packages.
    
    Requirement already satisfied: branca>=0.6.0 in c:\users\rahul\anaconda3\lib\site-packages (from folium) (0.7.2)
    Requirement already satisfied: jinja2>=2.9 in c:\users\rahul\anaconda3\lib\site-packages (from folium) (3.1.3)
    Requirement already satisfied: numpy in c:\users\rahul\anaconda3\lib\site-packages (from folium) (1.26.4)
    Requirement already satisfied: requests in c:\users\rahul\anaconda3\lib\site-packages (from folium) (2.31.0)
    Requirement already satisfied: xyzservices in c:\users\rahul\anaconda3\lib\site-packages (from folium) (2022.9.0)
    Requirement already satisfied: MarkupSafe>=2.0 in c:\users\rahul\anaconda3\lib\site-packages (from jinja2>=2.9->folium) (2.1.3)
    Requirement already satisfied: charset-normalizer<4,>=2 in c:\users\rahul\anaconda3\lib\site-packages (from requests->folium) (2.0.4)
    Requirement already satisfied: idna<4,>=2.5 in c:\users\rahul\anaconda3\lib\site-packages (from requests->folium) (3.4)
    Requirement already satisfied: urllib3<3,>=1.21.1 in c:\users\rahul\anaconda3\lib\site-packages (from requests->folium) (2.0.7)
    Requirement already satisfied: certifi>=2017.4.17 in c:\users\rahul\anaconda3\lib\site-packages (from requests->folium) (2024.2.2)
    


```python
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import folium
```


```python
d = pd.read_excel(r"C:\Users\rahul\Desktop\Monaco.xlsx")
```


```python
monaco_coords = [43.7347, 7.4206]
map_monaco = folium.Map(location=monaco_coords, zoom_start=15)
folium.Marker(
    location=monaco_coords,
    popup='Monaco Grand Prix Circuit',
    icon=folium.Icon(color='red', icon='info-sign')
).add_to(map_monaco)
map_monaco.save('monaco_grand_prix_map.html')
map_monaco
```




<div style="width:100%;"><div style="position:relative;width:100%;height:0;padding-bottom:60%;"><span style="color:#565656">Make this Notebook Trusted to load map: File -> Trust Notebook</span><iframe srcdoc="&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;

    &lt;meta http-equiv=&quot;content-type&quot; content=&quot;text/html; charset=UTF-8&quot; /&gt;

        &lt;script&gt;
            L_NO_TOUCH = false;
            L_DISABLE_3D = false;
        &lt;/script&gt;

    &lt;style&gt;html, body {width: 100%;height: 100%;margin: 0;padding: 0;}&lt;/style&gt;
    &lt;style&gt;#map {position:absolute;top:0;bottom:0;right:0;left:0;}&lt;/style&gt;
    &lt;script src=&quot;https://cdn.jsdelivr.net/npm/leaflet@1.9.3/dist/leaflet.js&quot;&gt;&lt;/script&gt;
    &lt;script src=&quot;https://code.jquery.com/jquery-3.7.1.min.js&quot;&gt;&lt;/script&gt;
    &lt;script src=&quot;https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js&quot;&gt;&lt;/script&gt;
    &lt;script src=&quot;https://cdnjs.cloudflare.com/ajax/libs/Leaflet.awesome-markers/2.0.2/leaflet.awesome-markers.js&quot;&gt;&lt;/script&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdn.jsdelivr.net/npm/leaflet@1.9.3/dist/leaflet.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.0/css/all.min.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdnjs.cloudflare.com/ajax/libs/Leaflet.awesome-markers/2.0.2/leaflet.awesome-markers.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdn.jsdelivr.net/gh/python-visualization/folium/folium/templates/leaflet.awesome.rotate.min.css&quot;/&gt;

            &lt;meta name=&quot;viewport&quot; content=&quot;width=device-width,
                initial-scale=1.0, maximum-scale=1.0, user-scalable=no&quot; /&gt;
            &lt;style&gt;
                #map_51b4a718999da8b51c39f79ae5bbbebf {
                    position: relative;
                    width: 100.0%;
                    height: 100.0%;
                    left: 0.0%;
                    top: 0.0%;
                }
                .leaflet-container { font-size: 1rem; }
            &lt;/style&gt;

&lt;/head&gt;
&lt;body&gt;


            &lt;div class=&quot;folium-map&quot; id=&quot;map_51b4a718999da8b51c39f79ae5bbbebf&quot; &gt;&lt;/div&gt;

&lt;/body&gt;
&lt;script&gt;


            var map_51b4a718999da8b51c39f79ae5bbbebf = L.map(
                &quot;map_51b4a718999da8b51c39f79ae5bbbebf&quot;,
                {
                    center: [43.7347, 7.4206],
                    crs: L.CRS.EPSG3857,
                    zoom: 15,
                    zoomControl: true,
                    preferCanvas: false,
                }
            );





            var tile_layer_ae82008c95f45adeaf15ec9475cca6d6 = L.tileLayer(
                &quot;https://tile.openstreetmap.org/{z}/{x}/{y}.png&quot;,
                {&quot;attribution&quot;: &quot;\u0026copy; \u003ca href=\&quot;https://www.openstreetmap.org/copyright\&quot;\u003eOpenStreetMap\u003c/a\u003e contributors&quot;, &quot;detectRetina&quot;: false, &quot;maxNativeZoom&quot;: 19, &quot;maxZoom&quot;: 19, &quot;minZoom&quot;: 0, &quot;noWrap&quot;: false, &quot;opacity&quot;: 1, &quot;subdomains&quot;: &quot;abc&quot;, &quot;tms&quot;: false}
            );


            tile_layer_ae82008c95f45adeaf15ec9475cca6d6.addTo(map_51b4a718999da8b51c39f79ae5bbbebf);


            var marker_acb587a6286110a8b22fdbceda941dfd = L.marker(
                [43.7347, 7.4206],
                {}
            ).addTo(map_51b4a718999da8b51c39f79ae5bbbebf);


            var icon_f4a5d8bf1785c1dd9eaf11417ecef167 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_acb587a6286110a8b22fdbceda941dfd.setIcon(icon_f4a5d8bf1785c1dd9eaf11417ecef167);


        var popup_2b92a367b296c207dccca407ffb6f349 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});



                var html_59f279f0a412f96bcb0821e00ef56b35 = $(`&lt;div id=&quot;html_59f279f0a412f96bcb0821e00ef56b35&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Monaco Grand Prix Circuit&lt;/div&gt;`)[0];
                popup_2b92a367b296c207dccca407ffb6f349.setContent(html_59f279f0a412f96bcb0821e00ef56b35);



        marker_acb587a6286110a8b22fdbceda941dfd.bindPopup(popup_2b92a367b296c207dccca407ffb6f349)
        ;




            tile_layer_ae82008c95f45adeaf15ec9475cca6d6.addTo(map_51b4a718999da8b51c39f79ae5bbbebf);

&lt;/script&gt;
&lt;/html&gt;" style="position:absolute;width:100%;height:100%;left:0;top:0;border:none !important;" allowfullscreen webkitallowfullscreen mozallowfullscreen></iframe></div></div>




```python
d     # looking at the data set
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Position</th>
      <th>Driver Name</th>
      <th>Team</th>
      <th>Points</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Charles Leclerc</td>
      <td>FERRARI</td>
      <td>25</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Oscar Piastri</td>
      <td>MCLAREN MERCEDES</td>
      <td>18</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Carlos Sainz</td>
      <td>FERRARI</td>
      <td>15</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Lando Norris</td>
      <td>MCLAREN MERCEDES</td>
      <td>12</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>George Russell</td>
      <td>MERCEDES</td>
      <td>10</td>
    </tr>
    <tr>
      <th>5</th>
      <td>6</td>
      <td>Max Verstappen</td>
      <td>RB HONDA RBPT</td>
      <td>8</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7</td>
      <td>Lewis Hamilton</td>
      <td>MERCEDES</td>
      <td>7</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8</td>
      <td>Yuki Tsunoda</td>
      <td>RB HONDA RBPT</td>
      <td>4</td>
    </tr>
    <tr>
      <th>8</th>
      <td>9</td>
      <td>Alexander Albon</td>
      <td>WILLIAMS MERCEDES</td>
      <td>2</td>
    </tr>
    <tr>
      <th>9</th>
      <td>10</td>
      <td>Pierre Gasly</td>
      <td>ALPINE RENAULT</td>
      <td>1</td>
    </tr>
    <tr>
      <th>10</th>
      <td>11</td>
      <td>Fernando Alonso</td>
      <td>ASTON MARTIN ARAMCO MERCEDES</td>
      <td>0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>12</td>
      <td>Daniel Ricciardo</td>
      <td>RB HONDA RBPT</td>
      <td>0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>13</td>
      <td>Valtteri Bottas</td>
      <td>KICK SAUBER FERRARI</td>
      <td>0</td>
    </tr>
    <tr>
      <th>13</th>
      <td>14</td>
      <td>Lance Stroll</td>
      <td>ASTON MARTIN ARAMCO MERCEDES</td>
      <td>0</td>
    </tr>
    <tr>
      <th>14</th>
      <td>15</td>
      <td>Logan Sargeant</td>
      <td>WILLIAMS MERCEDES</td>
      <td>0</td>
    </tr>
    <tr>
      <th>15</th>
      <td>16</td>
      <td>Zhou Guanyu</td>
      <td>KICK SAUBER FERRARI</td>
      <td>0</td>
    </tr>
    <tr>
      <th>16</th>
      <td>17</td>
      <td>Esteban Ocon</td>
      <td>ALPINE RENAULT</td>
      <td>0</td>
    </tr>
    <tr>
      <th>17</th>
      <td>18</td>
      <td>Sergio Perez</td>
      <td>RED BULL RACING HONDA RBPT</td>
      <td>0</td>
    </tr>
    <tr>
      <th>18</th>
      <td>19</td>
      <td>Nico Hulkenberg</td>
      <td>HAAS FERRARI</td>
      <td>0</td>
    </tr>
    <tr>
      <th>19</th>
      <td>20</td>
      <td>Kevin Magnussen</td>
      <td>HAAS FERRARI</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
d.isnull().sum()    #checking missing vslues
```




    Position       0
    Driver Name    0
    Team           0
    Points         0
    dtype: int64




```python
d.dtypes             #verifing data types
```




    Position        int64
    Driver Name    object
    Team           object
    Points          int64
    dtype: object




```python
duplicates = d.duplicated().sum()
duplicates                           # Duplicates
```




    0




```python
d['Team '].str.upper().str.strip()             # Standardize team names, Found out Team column has space.
#d.columns
```




    0                          FERRARI
    1                 MCLAREN MERCEDES
    2                          FERRARI
    3                 MCLAREN MERCEDES
    4                         MERCEDES
    5                    RB HONDA RBPT
    6                         MERCEDES
    7                    RB HONDA RBPT
    8                WILLIAMS MERCEDES
    9                   ALPINE RENAULT
    10    ASTON MARTIN ARAMCO MERCEDES
    11                   RB HONDA RBPT
    12             KICK SAUBER FERRARI
    13    ASTON MARTIN ARAMCO MERCEDES
    14               WILLIAMS MERCEDES
    15             KICK SAUBER FERRARI
    16                  ALPINE RENAULT
    17      RED BULL RACING HONDA RBPT
    18                    HAAS FERRARI
    19                    HAAS FERRARI
    Name: Team , dtype: object




```python
d.rename(columns={'Team ': 'Team'}, inplace=True)
d.rename(columns={'Points': 'Points'}, inplace=True)         # Changing Team name
d
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Position</th>
      <th>Driver Name</th>
      <th>Team</th>
      <th>Points</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Charles Leclerc</td>
      <td>FERRARI</td>
      <td>25</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Oscar Piastri</td>
      <td>MCLAREN MERCEDES</td>
      <td>18</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Carlos Sainz</td>
      <td>FERRARI</td>
      <td>15</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Lando Norris</td>
      <td>MCLAREN MERCEDES</td>
      <td>12</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>George Russell</td>
      <td>MERCEDES</td>
      <td>10</td>
    </tr>
    <tr>
      <th>5</th>
      <td>6</td>
      <td>Max Verstappen</td>
      <td>RB HONDA RBPT</td>
      <td>8</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7</td>
      <td>Lewis Hamilton</td>
      <td>MERCEDES</td>
      <td>7</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8</td>
      <td>Yuki Tsunoda</td>
      <td>RB HONDA RBPT</td>
      <td>4</td>
    </tr>
    <tr>
      <th>8</th>
      <td>9</td>
      <td>Alexander Albon</td>
      <td>WILLIAMS MERCEDES</td>
      <td>2</td>
    </tr>
    <tr>
      <th>9</th>
      <td>10</td>
      <td>Pierre Gasly</td>
      <td>ALPINE RENAULT</td>
      <td>1</td>
    </tr>
    <tr>
      <th>10</th>
      <td>11</td>
      <td>Fernando Alonso</td>
      <td>ASTON MARTIN ARAMCO MERCEDES</td>
      <td>0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>12</td>
      <td>Daniel Ricciardo</td>
      <td>RB HONDA RBPT</td>
      <td>0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>13</td>
      <td>Valtteri Bottas</td>
      <td>KICK SAUBER FERRARI</td>
      <td>0</td>
    </tr>
    <tr>
      <th>13</th>
      <td>14</td>
      <td>Lance Stroll</td>
      <td>ASTON MARTIN ARAMCO MERCEDES</td>
      <td>0</td>
    </tr>
    <tr>
      <th>14</th>
      <td>15</td>
      <td>Logan Sargeant</td>
      <td>WILLIAMS MERCEDES</td>
      <td>0</td>
    </tr>
    <tr>
      <th>15</th>
      <td>16</td>
      <td>Zhou Guanyu</td>
      <td>KICK SAUBER FERRARI</td>
      <td>0</td>
    </tr>
    <tr>
      <th>16</th>
      <td>17</td>
      <td>Esteban Ocon</td>
      <td>ALPINE RENAULT</td>
      <td>0</td>
    </tr>
    <tr>
      <th>17</th>
      <td>18</td>
      <td>Sergio Perez</td>
      <td>RED BULL RACING HONDA RBPT</td>
      <td>0</td>
    </tr>
    <tr>
      <th>18</th>
      <td>19</td>
      <td>Nico Hulkenberg</td>
      <td>HAAS FERRARI</td>
      <td>0</td>
    </tr>
    <tr>
      <th>19</th>
      <td>20</td>
      <td>Kevin Magnussen</td>
      <td>HAAS FERRARI</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
d['Team'] = d['Team'].str.title()           # Capitalizing Team column
d
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Position</th>
      <th>Driver Name</th>
      <th>Team</th>
      <th>Points</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Charles Leclerc</td>
      <td>Ferrari</td>
      <td>25</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Oscar Piastri</td>
      <td>Mclaren Mercedes</td>
      <td>18</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Carlos Sainz</td>
      <td>Ferrari</td>
      <td>15</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Lando Norris</td>
      <td>Mclaren Mercedes</td>
      <td>12</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>George Russell</td>
      <td>Mercedes</td>
      <td>10</td>
    </tr>
    <tr>
      <th>5</th>
      <td>6</td>
      <td>Max Verstappen</td>
      <td>Rb Honda Rbpt</td>
      <td>8</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7</td>
      <td>Lewis Hamilton</td>
      <td>Mercedes</td>
      <td>7</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8</td>
      <td>Yuki Tsunoda</td>
      <td>Rb Honda Rbpt</td>
      <td>4</td>
    </tr>
    <tr>
      <th>8</th>
      <td>9</td>
      <td>Alexander Albon</td>
      <td>Williams Mercedes</td>
      <td>2</td>
    </tr>
    <tr>
      <th>9</th>
      <td>10</td>
      <td>Pierre Gasly</td>
      <td>Alpine Renault</td>
      <td>1</td>
    </tr>
    <tr>
      <th>10</th>
      <td>11</td>
      <td>Fernando Alonso</td>
      <td>Aston Martin Aramco Mercedes</td>
      <td>0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>12</td>
      <td>Daniel Ricciardo</td>
      <td>Rb Honda Rbpt</td>
      <td>0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>13</td>
      <td>Valtteri Bottas</td>
      <td>Kick Sauber Ferrari</td>
      <td>0</td>
    </tr>
    <tr>
      <th>13</th>
      <td>14</td>
      <td>Lance Stroll</td>
      <td>Aston Martin Aramco Mercedes</td>
      <td>0</td>
    </tr>
    <tr>
      <th>14</th>
      <td>15</td>
      <td>Logan Sargeant</td>
      <td>Williams Mercedes</td>
      <td>0</td>
    </tr>
    <tr>
      <th>15</th>
      <td>16</td>
      <td>Zhou Guanyu</td>
      <td>Kick Sauber Ferrari</td>
      <td>0</td>
    </tr>
    <tr>
      <th>16</th>
      <td>17</td>
      <td>Esteban Ocon</td>
      <td>Alpine Renault</td>
      <td>0</td>
    </tr>
    <tr>
      <th>17</th>
      <td>18</td>
      <td>Sergio Perez</td>
      <td>Red Bull Racing Honda Rbpt</td>
      <td>0</td>
    </tr>
    <tr>
      <th>18</th>
      <td>19</td>
      <td>Nico Hulkenberg</td>
      <td>Haas Ferrari</td>
      <td>0</td>
    </tr>
    <tr>
      <th>19</th>
      <td>20</td>
      <td>Kevin Magnussen</td>
      <td>Haas Ferrari</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
d.describe()                  # Descriptive Statistics
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Position</th>
      <th>Points</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>20.00000</td>
      <td>20.00000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>10.50000</td>
      <td>5.10000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>5.91608</td>
      <td>7.36921</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.00000</td>
      <td>0.00000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>5.75000</td>
      <td>0.00000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>10.50000</td>
      <td>0.50000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>15.25000</td>
      <td>8.50000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>20.00000</td>
      <td>25.00000</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize=(6, 3))
sns.histplot(d['Points'])                     # Historgram graph of showing how many drivers have got 0 points
plt.title('Distribution of Points')
plt.xlabel('Points')
plt.ylabel('Frequency')
plt.show()
```

    C:\Users\rahul\anaconda3\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_12_1.png)
    



```python
top_drivers = d.sort_values(by='Points', ascending=False).head(10)           # Top drivers of 1st 10 drivers who  
top_drivers
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Position</th>
      <th>Driver Name</th>
      <th>Team</th>
      <th>Points</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Charles Leclerc</td>
      <td>Ferrari</td>
      <td>25</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Oscar Piastri</td>
      <td>Mclaren Mercedes</td>
      <td>18</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Carlos Sainz</td>
      <td>Ferrari</td>
      <td>15</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Lando Norris</td>
      <td>Mclaren Mercedes</td>
      <td>12</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>George Russell</td>
      <td>Mercedes</td>
      <td>10</td>
    </tr>
    <tr>
      <th>5</th>
      <td>6</td>
      <td>Max Verstappen</td>
      <td>Rb Honda Rbpt</td>
      <td>8</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7</td>
      <td>Lewis Hamilton</td>
      <td>Mercedes</td>
      <td>7</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8</td>
      <td>Yuki Tsunoda</td>
      <td>Rb Honda Rbpt</td>
      <td>4</td>
    </tr>
    <tr>
      <th>8</th>
      <td>9</td>
      <td>Alexander Albon</td>
      <td>Williams Mercedes</td>
      <td>2</td>
    </tr>
    <tr>
      <th>9</th>
      <td>10</td>
      <td>Pierre Gasly</td>
      <td>Alpine Renault</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
top_teams = d.groupby('Team')['Points'].sum().sort_values(ascending=False).reset_index()   #Top teams
top_teams
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Team</th>
      <th>Points</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Ferrari</td>
      <td>40</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Mclaren Mercedes</td>
      <td>30</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Rb Honda Rbpt</td>
      <td>12</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Mercedes</td>
      <td>10</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Mercedes</td>
      <td>7</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Williams Mercedes</td>
      <td>2</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Alpine Renault</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Aston Martin Aramco Mercedes</td>
      <td>0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Haas Ferrari</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Kick Sauber Ferrari</td>
      <td>0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Red Bull Racing Honda Rbpt</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
correlation = d[['Position', 'Points']].corr()           # Correlation between position and points
correlation  
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Position</th>
      <th>Points</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Position</th>
      <td>1.000000</td>
      <td>-0.857136</td>
    </tr>
    <tr>
      <th>Points</th>
      <td>-0.857136</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
print(d.columns)
```

    Index(['Position', 'Driver Name', 'Team', 'Points'], dtype='object')
    


```python
plt.figure(figsize=(15, 6))
df = d.sort_values(by='Points', ascending=False)
sns.barplot(x='Driver Name', y='Points', data=df)
plt.title('Total Points by Driver')
plt.xlabel('Driver Name')
plt.ylabel('Total Points')
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()
```


    
![png](output_17_0.png)
    



```python
plt.figure(figsize=(15, 6))
sns.barplot(x='Team', y='Points', data=d, ci = None)
plt.title('Total Points of Team')
plt.xlabel('Team')
plt.xticks(rotation=45)
plt.ylabel('Top Team')
plt.tight_layout()
plt.show()
```

    C:\Users\rahul\AppData\Local\Temp\ipykernel_10592\3210708193.py:2: FutureWarning: 
    
    The `ci` parameter is deprecated. Use `errorbar=None` for the same effect.
    
      sns.barplot(x='Team', y='Points', data=d, ci = None)
    


    
![png](output_18_1.png)
    



```python
plt.figure(figsize=(8,5))
sns.barplot(x='Points',y='Driver Name', data = d)
plt.title("Points by Driver")
plt.xlabel('Points')
plt.ylabel('Driver Name')
plt.show()
```


    
![png](output_19_0.png)
    



```python
plt.figure(figsize=(8,5))
sns.barplot(x = 'Points', y = 'Team', data =d , ci=None)
plt.title('Points by Teams')
plt.xlabel('Team')
plt.ylabel('Points')
plt.show()
```

    C:\Users\rahul\AppData\Local\Temp\ipykernel_10592\2602617143.py:2: FutureWarning: 
    
    The `ci` parameter is deprecated. Use `errorbar=None` for the same effect.
    
      sns.barplot(x = 'Points', y = 'Team', data =d , ci=None)
    


    
![png](output_20_1.png)
    



```python
drivers = d['Driver Name']
points = d['Points']

plt.figure(figsize=(15, 10))
wedges, texts, autotexts = plt.pie(points, labels=None, autopct='%1.1f%%', startangle=360, colors=plt.cm.tab20.colors)

plt.legend(wedges, drivers, title="Drivers", loc="center left", bbox_to_anchor=(1, 0, 0.5, 1))
plt.title('Points by the Driver')
plt.axis('equal')
plt.show()
```


    
![png](output_21_0.png)
    


### Conclusion

In this analysis of the Monaco Race 2024 data, several key insights were uncovered regarding the drivers, teams, and their performances:

- **Top Performers**: Charles Leclerc emerged as the leading driver with 25 points, followed closely by Oscar Piastri with 18 points. Ferrari and McLaren Mercedes were the top-performing teams with 40 and 30 points, respectively.
- **Distribution of Points**: A histogram of driver points revealed that a significant number of drivers did not score any points, highlighting the competitive nature of the race.
- **Correlation Analysis**: There was a strong negative correlation (-0.857) between a driver's position and their points, indicating that higher positions correlated with lower points, which is expected in race standings.
- **Visual Insights**: Visualizations such as bar plots and pie charts provided clear representations of points distribution among drivers and teams, offering a comprehensive overview of performance metrics.

This analysis not only provides a snapshot of individual and team performances but also serves as a foundation for understanding the dynamics of the Monaco Grand Prix 2024. These insights are crucial for strategic decision-making and further exploration in the realm of motorsports analytics.

